import pandas as pd
import json
import numpy as np

# Names of the common properties
SOURCE_URL = 'source_url'
PUBLISHED_DATE = 'published_date'
TITLE = 'title'
CONTENT = 'content'
SOURCE = 'source'
AUTHOR = 'author'
NS = 'http://www.tentex.io/data/news'

def add_header(json_ld, source_dataset, source_dataset_id):
    elastic_search_id = f'{source_dataset}/{source_dataset_id}'
    uri = f'{NS}/{elastic_search_id}'
    json_ld['_id'] = elastic_search_id
    json_ld['uri'] = uri
    json_ld['source_dataset'] = source_dataset
    json_ld['source_dataset_id'] = source_dataset_id
    return json_ld

# Known formats
# ,title, author, date, ontology, crawled_time, url, content, topic_area
# ,title, date, ontology, url, author, content, topic_area
# ,title, author, date, ontology, url, content, topic_area
# ,title, author, date, ontology, crawled_time, url, content,topic_area

def covid19_json_document_generator(file_path, source_dataset):
    """Reads the file through pd.read_csv() and for each row
    yields a single document. This function is passed into the bulk()
    helper to create many documents in sequence.
    """
    df = pd.read_csv(file_path)
    for index, row in df.iterrows():
        json_ld = {
            SOURCE_URL: row['url'],
            PUBLISHED_DATE: row['date'],
            TITLE: row['title'],
            CONTENT: row['content'],
            SOURCE: row['domain'],
            # specific for this dataset
            'topic_area': row['topic_area']
        }
        # Some attributes are not always there
        if AUTHOR in row and not row['author'] is np.nan:
            json_ld['author'] = row['author']

        source_dataset_id = row[0]
        json_ld = add_header(json_ld, source_dataset, source_dataset_id)
        yield json_ld


def aylien_json_document_generator(file_path, source_dataset):
    with open(file_path) as fp:
        for index, line in enumerate(fp):
            row = json.loads(line)
            json_ld = {
                SOURCE_URL: row['links']['permalink'],
                PUBLISHED_DATE: row['published_at'],
                TITLE: row['title'],
                CONTENT: row['body'],
                SOURCE: row['source']['domain'],
                AUTHOR: row['author']['name'],

                # Specific for this dataset
                'hashtags': row['hashtags'],
                'keywords': row['keywords'],
                'media': row['media'],
                'entities': row['entities'],
                'social_shares_count': row['social_shares_count'],
                'summary': row['summary'],
                'sentiment': row['sentiment']
            }

            if row['media']:
                urls = [current['url'] for current in row['media']]
                json_ld['image_urls'] = urls

            source_dataset_id = row['id']
            json_ld = add_header(json_ld, source_dataset, source_dataset_id)

            yield json_ld


def ieee_json_document_generator(file_path, source_dataset):
    with open(file_path) as fp:
        for index, line in enumerate(fp):
            row = json.loads(line)
            json_ld = {
                SOURCE_URL: row['url'],
                PUBLISHED_DATE: row['published'],
                TITLE: row['title'],
                CONTENT: row['text'],
                AUTHOR: row['author'],
                SOURCE: row['thread']['site_full'],

                # Specific for this dataset
                'thread': row['thread'],
            }

            source_dataset_id = row['uuid']
            json_ld = add_header(json_ld, source_dataset, source_dataset_id)

            yield json_ld


def select_json_document_generator(file_path, file):
    dataset_name = file.rstrip('.sample')
    if file.startswith('covid19'):
        dataset_name = dataset_name.rstrip('.csv')
        generator = covid19_json_document_generator(file_path, dataset_name)
        return dataset_name, generator
    elif file.startswith('aylien'):
        dataset_name = dataset_name.rstrip('.jsonl')
        generator = aylien_json_document_generator(file_path, dataset_name)
        return dataset_name, generator
    elif file.startswith('16119'):
        dataset_name = dataset_name.rstrip('.json')
        generator = ieee_json_document_generator(file_path, dataset_name)
        return dataset_name, generator
    else:
        raise NotImplemented
