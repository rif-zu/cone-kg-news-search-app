from rdflib import Graph, Literal, RDF, URIRef
from rdflib.namespace import XSD, ClosedNamespace


# create a Graph
from triplifier.rdf.ontology import FNO

graph = Graph()

NS = 'http://www.tentex.io/data/news'
# NS = 'http://www.fakenews.com/data'
ID = 'ieee/1521018'

event_uri = URIRef(f'{NS}/event/{ID}')
media_uri = URIRef(f'{NS}/social-media-object/{ID}')
title = URIRef(f'{NS}/title/{ID}')
organization = URIRef(f'{NS}/organisation/{ID}')
image = URIRef(f'{NS}/image/{ID}')
image_url = URIRef(f'{NS}/image/url/{ID}')
publisher = URIRef("http://www.fakenews.com/data/publisher/Radhakrishnan-Kuttoor")
date = URIRef(f'{NS}/input_data/date/{ID}')


# <http://www.fakenews.com/data/event/ieee-1521018>
#   a <http://www.semanticweb.org/developer/ontologies/2020/3/Fake_news_Ontology#Covid19_News_Transmission_Event> ;
#   fno:hasPublisher <http://www.fakenews.com/data/publisher/Radhakrishnan-Kuttoor> ;
#   fno:hasContent <http://www.fakenews.com/data/social-media-object/ieee-1521018> .

graph.add((event_uri, RDF.type, FNO.Covid19_News_Transmission_Event))


contents = '''
COVID-19 has started stealing the sheen off marriages and other ceremonies in Pathanamthitta, Kerala, a district otherwise known for its pompous weddings and ceremonial festivals.

Vishnu Panackal, an employee of Pathanamthitta Service Cooperative Bank, tied the knot with Parvathy, a paddy analyst attached to the Civil Supplies Corporation, at a simple function held at the Muringamangalam Mahadevar temple at Konni on Thursday. The families had invited 2,000 people well in advance. A well-known catering group was in charge of the feast.

Then came the COVID-19 threat, shattering all their plans and dreams. Pathanamthitta hit the headlines, with Ranni becoming the epicentre of State’s second spell of COVID-19 infection on March 7. The government imposed restrictions on people’s movement and on public and private functions.

Parents of Vishnu and Parvathy advertised in regional newspapers informing invitees of the decision to cancel the ceremonial part of the wedding.

Hardly 50 persons, family members and close relatives, turned up for the wedding. All of them were given face masks. Sanitiser too was available to clean their hands. Tying the knot was held without any fanfare.
'''

# <http://www.fakenews.com/data/publisher/Radhakrishnan-Kuttoor>
#   a fno:Social_Media_Agent ;
#   fno:hasName "Radhakrishnan Kuttoor" .
graph.add((event_uri, FNO.hasPublisher, publisher))
graph.add((publisher, RDF.type, FNO.Social_Media_Agent))
graph.add((publisher, FNO.hasName, Literal('Radhakrishnan Kuttoor')))

# <http://www.fakenews.com/data/social-media-object/ieee-1521018>
#   a fno:Social_Media_Object ;
#   fno:hasPublishedDate <http://www.fakenews.com/data/date/ieee-1521018> ;
#   fno:hasUrl <http://www.fakenews.com/data/url/ieee-1521018> ;
#   fno:hasPart <http://www.fakenews.com/data/organisation/ieee-1521018>, <http://www.fakenews.com/data/image/ieee-1521018> ;
#   fno:hasSocialMetaData <http://www.fakenews.com/data/title/ieee-1521018> .


graph.add((media_uri, RDF.type, FNO.Social_Media_Object))
graph.add((event_uri, FNO.hasContent, media_uri))
graph.add((media_uri, FNO.socialMediaContent, Literal(contents)))


# <http://www.fakenews.com/data/date/ieee-1521018>
#   a fno:Date ;
#   fno:hasDate "2020-03-19"^^xsd:dateTime .
graph.add((media_uri, FNO.hasPublishedDate, date))
graph.add((date, RDF.type, FNO.Date))
graph.add((date, FNO.hasDate, Literal("2020-03-19", datatype=XSD.dateTime)))

# <http://www.fakenews.com/data/organisation/ieee-1521018>
#   a fno:Social_Metadata ;
#   fno:hasDescription "pathanamthitta service cooperative bank" .
graph.add((organization, RDF.type, FNO.Social_Metadata))
graph.add((organization, FNO.hasDescription, Literal("pathanamthitta service cooperative bank")))
graph.add((media_uri, FNO.hasPart, organization))

# <http://www.fakenews.com/data/url/ieee-1521018>
#   a fno:Url ;
#   fno:urlAddress "https://www.thehindu.com/news/national/kerala/wedding-in-the-time-of-virus/article31111653.ece"

source_url = URIRef(f'{NS}/url/{ID}')
graph.add((source_url, RDF.type, FNO.Url))
graph.add((source_url, FNO.urlAddress,
           URIRef("https://www.thehindu.com/news/national/kerala/wedding-in-the-time-of-virus/article31111653.ece")))
graph.add((media_uri, FNO.hasUrl, source_url))

# <http://www.fakenews.com/data/image/ieee-1521018>
#   a fno:Image ;
#   fno:hasUrl <http://www.fakenews.com/data/image/url/ieee-1521018> .
graph.add((image, RDF.type, FNO.Image))
graph.add((image, FNO.hasUrl, image_url))
graph.add((media_uri, FNO.hasPart, image))

# <http://www.fakenews.com/data/image/url/ieee-1521018>
#   a fno:Url ;
#   fno:urlAddress "https://www.thehindu.com/news/national/kerala/4fstuv/article31111652.ece/ALTERNATES/LANDSCAPE_615/20tvpt-mask" .
graph.add((image_url, RDF.type, FNO.Url))
graph.add((image_url, FNO.urlAddress, URIRef(
    'https://www.thehindu.com/news/national/kerala/4fstuv/article31111652.ece/ALTERNATES/LANDSCAPE_615/20tvpt-mask')))

# <http://www.fakenews.com/data/title/ieee-1521018>
#   a fno:Title ;
#   fno:hasDescription "Wedding in the time of virus" .
graph.add((title, RDF.type, FNO.Title))
graph.add((title, FNO.hasDescription, Literal("Wedding in the time of virus")))
graph.add((media_uri, FNO.hasSocialMetaData, title))

graph.bind("fno", FNO)

print(graph.serialize(format='n3').decode("utf-8"))
