from urllib.parse import urlparse
import urllib.parse


def uri_validator(x):
    try:
        result = urlparse(x)
        return all([result.scheme, result.netloc, result.path])
    except:
        return False


def is_url(url):
  try:
    result = urlparse(url)
    return all([result.scheme, result.netloc])
  except ValueError:
    return False

def fix(s):
  i = s.rindex('/')
  return s[:i] + urllib.parse.quote(s[i:])

def fix_url(url):
    return urllib.parse.quote(url, "./_-:")

url = 'https://www.otcmarkets.com/stock/TAKOF/news/Drone-Delivery-Canada-Deemed-an-\%3Fid%3D257351'
url = fix_url(url)
print(url)
print(is_url(url))
