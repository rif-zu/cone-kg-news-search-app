from rdflib import Graph, Literal, RDF, URIRef
from rdflib.namespace import XSD
import hashlib
import urllib.parse
from rdflib.term  import _is_valid_uri
from config import NS
from triplifier.rdf.ontology import FNO

# Some URLs from the dataset are not well formed
def fix_url(url):
    return urllib.parse.quote(url, "./_-:")

def hash(text):
    return hashlib.md5(text.encode()).hexdigest()

class Event:

    def __init__(self, identifier, contents, graph=None):
        if graph is None:
            graph = Graph()
        self.graph = graph
        self.identifier = identifier

        # Create the transmission event
        self.event_uri = URIRef(f'{NS}/{self.identifier}')
        self.graph.add((self.event_uri, RDF.type, FNO.Covid19_News_Transmission_Event))

        # Create the social media object
        self.media_uri = URIRef(f'{NS}/social-media-object/{self.identifier}')
        self.graph.add((self.media_uri, RDF.type, FNO.Social_Media_Object))
        self.graph.add((self.event_uri, FNO.hasContent, self.media_uri))

        # Add the main content
        self.graph.add((self.media_uri, FNO.socialMediaContent, Literal(contents)))

    def add_url(self, url):
        url = fix_url(url)
        if _is_valid_uri(url):
            uri = URIRef(f'{NS}/url/{self.identifier}')
            self.graph.add((uri, RDF.type, FNO.Url))
            self.graph.add((uri, FNO.urlAddress,
                            URIRef(url)))
            self.graph.add((self.media_uri, FNO.hasUrl, uri))

    def add_title(self, title):
        uri = URIRef(f'{NS}/title/{self.identifier}')
        self.graph.add((uri, RDF.type, FNO.Title))
        self.graph.add((uri, FNO.hasDescription, Literal(title)))
        self.graph.add((self.media_uri, FNO.hasSocialMetaData, uri))

    def add_publisher(self, publisher_name, publisher_id=None):
        uri = URIRef(f'{NS}/publisher/{hash(publisher_name)}') if publisher_id is None else \
            URIRef(f'{NS}/publisher/{publisher_id}')

        self.graph.add((uri, RDF.type, FNO.Social_Media_Agent))
        self.graph.add((uri, FNO.hasName, Literal(publisher_name)))
        self.graph.add((self.event_uri, FNO.hasPublisher, uri))

    def add_organization(self, organization, organization_id=None):
        uri = URIRef(f'{NS}/organisation/{hash(organization)}') if organization_id is None else \
            URIRef(f'{NS}/organisation/{organization_id}')
        self.graph.add((uri, RDF.type, FNO.Social_Metadata))
        self.graph.add((uri, FNO.hasDescription, Literal(organization)))
        self.graph.add((self.media_uri, FNO.hasPart, uri))

    def add_image(self, image_url):
        image_url = fix_url(image_url)
        if _is_valid_uri(image_url):
            uri = URIRef(f'{NS}/image/{hash(image_url)}')
            url_uri = URIRef(f'{NS}/image/url/{hash(image_url)}')
            self.graph.add((uri, RDF.type, FNO.Image))
            self.graph.add((uri, FNO.hasUrl, url_uri))
            self.graph.add((url_uri, RDF.type, FNO.Url))
            self.graph.add((url_uri, FNO.urlAddress, URIRef(
                image_url)))
            self.graph.add((self.media_uri, FNO.hasPart, uri))

    def add_date(self, date):
        uri = URIRef(f'{NS}/input_data/date/{self.identifier}')
        self.graph.add((uri, RDF.type, FNO.Date))
        self.graph.add((uri, FNO.hasDate, Literal(date, datatype=XSD.dateTime)))
        self.graph.add((self.media_uri, FNO.hasPublishedDate, uri))


def example():
    contents = '''
    COVID-19 has started stealing the sheen off marriages and other ceremonies in Pathanamthitta, Kerala, a district otherwise known for its pompous weddings and ceremonial festivals.
    
    Vishnu Panackal, an employee of Pathanamthitta Service Cooperative Bank, tied the knot with Parvathy, a paddy analyst attached to the Civil Supplies Corporation, at a simple function held at the Muringamangalam Mahadevar temple at Konni on Thursday. The families had invited 2,000 people well in advance. A well-known catering group was in charge of the feast.
    
    Then came the COVID-19 threat, shattering all their plans and dreams. Pathanamthitta hit the headlines, with Ranni becoming the epicentre of State’s second spell of COVID-19 infection on March 7. The government imposed restrictions on people’s movement and on public and private functions.
    
    Parents of Vishnu and Parvathy advertised in regional newspapers informing invitees of the decision to cancel the ceremonial part of the wedding.
    
    Hardly 50 persons, family members and close relatives, turned up for the wedding. All of them were given face masks. Sanitiser too was available to clean their hands. Tying the knot was held without any fanfare.
    '''
    ID = 'ieee/1521018'
    event = Event(ID, contents)
    event.add_date('2020-03-19')
    event.add_image(
        'https://www.thehindu.com/news/national/kerala/4fstuv/article31111652.ece/ALTERNATES/LANDSCAPE_615/20tvpt-mask')
    event.add_url('https://www.thehindu.com/news/national/kerala/wedding-in-the-time-of-virus/article31111653.ece')
    event.add_image('https://www.example.image/2')
    event.add_organization('pathanamthitta service cooperative bank')
    event.add_title('Wedding in the time of virus')
    event.add_publisher('Radhakrishnan Kuttoor', None)
    graph = event.graph
    graph.bind("fno", FNO)
    print(graph.serialize(format='n3').decode("utf-8"))


if __name__ == '__main__':
    example()
