from rdflib import Graph, Literal, RDF, URIRef
from rdflib.namespace import XSD, ClosedNamespace

FNO = ClosedNamespace(
    uri=URIRef('http://www.semanticweb.org/developer/ontologies/2020/3/Fake_news_Ontology#'),
    terms=[
        'Covid19_News_Transmission_Event',
        'Social_Media_Object',
        'hasPublisher',
        'hasContent',
        'hasPublishedDate',
        'hasUrl',
        'hasPart',
        'hasSocialMetaData',
        'hasDate',
        'Date',
        'Social_Metadata',
        'hasDescription',
        'Url',
        'urlAddress',
        'Image',
        'hasUrl',
        'Title',
        'hasDescription',
        'socialMediaContent',
        'Social_Media_Agent',
        'hasName'
    ]
)