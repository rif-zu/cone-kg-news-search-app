# Transform raw data and indexing

## Install dependencies

```
pip install -r requirements.txt
```
## generators

1. JSON

There are three methods to create JSON from distinct data sources.

- ./generators/covid19_json_document_generator
- ./generators/aylien_json_document_generator
- ./generators/ieee_json_document_generator

2. TTL

There are three methods to create RDF from distinct data sources (to develop?)

- ./generators/rdf_triples_generators/covid19_triples_generator
- ./generators/rdf_triples_generators/aylien_triples_generator
- ./generators/rdf_triples_generators/ieee_triples_generator


## elastic_search_indexer.py
 
It takes the data present into the 'data' folder to:
- parse them using the Json generators
- push the generated documents into the elastic search instance.

## knowledge graph triplifier.py 

It takes the data present into the 'data' folder to:
- parse them using the generators
- expose triples. 
    - Store them somewhere? Generate a file?
