import os
import random
from triplifier.util import progbar
from pathlib import Path
import pandas as pd

# An utility to generate small amples of the input_data,
# I used this to build small datasets that are faster to process at development time

OUTPUT_DIRECTORY = './input_data'
SAMPLE_SIZE = 1184382

# OUTPUT_DIRECTORY = './big_data'
# SAMPLE_SIZE = 10000

def sample_jsonl(filename, number_of_lines, sample_size=SAMPLE_SIZE):
    all_lines = list(range(number_of_lines))
    sample_lines = random.choices(all_lines, k=sample_size)

    output_filename =os.path.join(OUTPUT_DIRECTORY, f'{Path(filename).name}.sample')
    print(f'\nSampling: {output_filename}')
    output = open(output_filename, "w+")
    with open(filename) as fp:
        for cnt, line in enumerate(fp):
            # Check if this line was chosen in the sample
            if cnt in sample_lines:
                output.write(line)
            progbar(cnt, number_of_lines, 20)
    output.close()


def sample_csv(filename):
    df = pd.read_csv(filename, index_col=0)
    output_filename = os.path.join(OUTPUT_DIRECTORY, f'{Path(filename).name}.sample')
    df.sample(n=SAMPLE_SIZE).to_csv(output_filename)

def index_samples():
    # File, number of lines, is csv
    files = [
        ('/media/cvasquez/Samsung_T5/Covid/data_sources/613860_1191823_bundle_archive/covid19_articles.csv',
         53009,
         True),
        ('/media/cvasquez/Samsung_T5/Covid/data_sources/613860_1191823_bundle_archive/covid19_articles_20200504.csv',
         56031,
         True),
        ('/media/cvasquez/Samsung_T5/Covid/data_sources/613860_1191823_bundle_archive/covid19_articles_20200512.csv',
         61464,
         True),
        ('/media/cvasquez/Samsung_T5/Covid/data_sources/613860_1191823_bundle_archive/covid19_articles_20200526.csv',
         81169,
         True),
        ('/media/cvasquez/Samsung_T5/Covid/data_sources/aylien_covid_news_data.jsonl',
         1184382,
         False),
        ('/media/cvasquez/Samsung_T5/Covid/data_sources/16119_webhose_2020_03_db21c91a1ab47385bb13773ed8238c31_0000023.json',
        62419,
        False)
    ]

    for (filename, number_of_lines, is_csv) in files:
        if not is_csv:
            sample_jsonl(filename=filename, number_of_lines=number_of_lines)
        else:
            sample_csv(filename=filename)

if __name__ == "__main__":
    index_samples()
