NS = 'http://www.tentex.io/data/news'

INPUT_DATA_DIR='/home/ubuntu/data'
OUTPUT_DATA_DIR='/home/ubuntu/triples'

# The credentials of the elastic search server
ES_USERNAME = 'elastic'
ES_PASSWORD = 'changeme'
ES_ENDPOINT = 'http://localhost:9200'
