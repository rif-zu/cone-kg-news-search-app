# Cone-KG News Search app

Install the dependencies
```
npm install
```


Run the application:
```
npm run serve
```
