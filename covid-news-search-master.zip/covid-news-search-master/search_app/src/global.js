if (typeof window !== 'undefined') module.exports = window
