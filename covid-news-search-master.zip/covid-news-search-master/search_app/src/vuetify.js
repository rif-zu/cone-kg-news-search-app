import Vue from 'vue'
import Vuetify from 'vuetify/lib'
import store from '@/store'
import '@mdi/font/css/materialdesignicons.css'
import colors from 'vuetify/lib/util/colors'

Vue.use(Vuetify)

const vuetify = new Vuetify(
  {

    icons: {
      iconfont: 'mdi'
    },
    theme: {
      themes: {
        light: {
          primary: '#3f51b5',
          secondary: '#b0bec5',
          accent: '#8c9eff',
          error: '#b71c1c'
        },
        dark: {
          primary: colors.blue.lighten3,
        },
      },
    },
  }
)

export default vuetify
