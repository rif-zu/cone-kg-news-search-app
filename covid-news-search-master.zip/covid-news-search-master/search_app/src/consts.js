/**
 * Different states to distinguish current connection status, also displayed in navbar.
 * - UNKNOWN: initial state
 * - SUCCESS: set after successful connection
 * - ERROR:   set if any error happens
 * @type {{UNKNOWN: string, SUCCESS: string, ERROR: string}}
 */

/**
 * Elastic search config
 */
export const DEFAULT_HOST = 'http://elastic:changeme@18.133.76.183:9200'

/**
 * SPARQL config
 */
export const SPARQL_ENDPOINT = 'http://18.134.14.161:8890/sparql'

/**
 * NER Service config
 */
export const NER_SERVICE_HOST = 'http://18.134.14.161:8080/ent'

/**
 * Default keywords for boosting
 */
const DEFAULT_KEYWORDS = [
  'coronavirus', 'covid-19', 'pandemic', 'symptoms', 'vaccine',
  'vacination', 'pandemic', 'virus', 'masks',
  'face masks', 'respirator', 'lockdown', 'sanitisers', 'asymptomatic',
  'clinical trial', 'contact tracing', 'epidemic', 'hydroxychloroquine',
  'PPE', 'social distancing', 'remdesivir', 'SARS-CoV2', 'self-isolation',
  'self-quarantine', 'super-spreader', 'symptomatic', 'stay safe',
  'hand washing'
]

function getBoost(){
  let result = ''
  for (let current of DEFAULT_KEYWORDS){
    result+=` title:(${current})^1 content:(${current})^1`
  }
  return result;
}
const DEFAULT_KEYWORDS_BOOST = getBoost()

/**
 * Query for the articles shown upfront
 */
export const search_popular = function search_popular() {
  let random_keyword = DEFAULT_KEYWORDS[Math.floor(Math.random() * DEFAULT_KEYWORDS.length)];
  return `title:(${random_keyword})^7 content:(${random_keyword})^3`
}
/**
 * Default search query, taking into account the keywords for boosting
 */
export const search_dsl = function search_dsl(query_text) {
  return `title:(${query_text})^7 content:(${query_text})^3 ${DEFAULT_KEYWORDS_BOOST}`
}



/**
 * Default search parameters for search and search pages.
 * @type {{q: string, from: number, size: number, index: Array}}
 */
export const DEFAULT_SEARCH_PARAMS = {
  q: '',
  from: 0,
  size: 1000,
  _source: '',
  index: '*'
}
/**
 * Misc
 */
export const LOCALSTORAGE_KEY = 'elasticvuex'

export const REQUEST_DEFAULT_HEADERS = {
  'Accept': 'application/json',
  'Content-Type': 'application/json'
}

export const DEFAULT_ITEMS_PER_PAGE = [10, 20, 100, {text: 'All', value: -1}]

export const DEFAULT_DATA_TABLE_OPTIONS = {
  page: 1,
  itemsPerPage: DEFAULT_ITEMS_PER_PAGE[0],
  sortBy: [],
  sortByDesc: []
}
export const HTTP_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']

export const BASE_URI = process.env.VUE_APP_ROUTER_MODE ? 'index.html' : '/'

export const CONNECTION_STATES = {
  UNKNOWN: 'unknown',
  SUCCESS: 'success',
  ERROR: 'error'
}
