import Request from '../../mixins/Request'
import esAdapter from '@/mixins/GetAdapter'
import {showErrorSnackbar} from '@/mixins/ShowSnackbar'
import {DEFAULT_HOST} from '@/consts'

export default {
  name: 'connect-base',
  mixins: [Request],
  data() {
    return {
      testError: false,
      testSuccess: false,
      testLoading: false,
      connectLoading: false,
      connectError: false,
      errorMessage: '',
      hostEqual: true
    }
  },
  computed: {
    elasticsearchHost: {
      get() {
        return this.$store.state.connection.elasticsearchHost
      },
      set(value) {
        this.connectError = false
        this.testError = false
        this.testSuccess = false
        this.testLoading = false
        this.hostEqual = false
        this.$store.commit('connection/setElasticsearchHost', value)
      }
    },
    hostValid() {
      return this.elasticsearchHost.match(/^https?:\/\//) ? true : 'Host most contain a valid scheme'
    }
  },
  methods: {
    connect() {
      this.elasticsearchHost = DEFAULT_HOST
      this.connectLoading = true
      this.connectError = false
      esAdapter()
        .then(() => {
          this.$store.commit('connection/setConnected')
          this.connectLoading = false
          this.connectError = false
          // showSuccessSnackbar({ text: 'Successfully connected.' })
          this.$router.go(-1)

        })
        .catch(() => {
          this.connectLoading = false
          this.connectError = true
          showErrorSnackbar({text: 'Error: could not connect.'})
        })
    }
  }
}
