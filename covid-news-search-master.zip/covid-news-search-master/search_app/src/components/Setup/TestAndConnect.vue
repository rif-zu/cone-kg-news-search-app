<template>
  <div>
  </div>
</template>

<script>
  import ConnectBase from '@/components/Setup/ConnectBase'

  export default {
    name: 'test-and-connect',
    extends: ConnectBase,
    created: async function () {
      this.connect()
    }
  }
</script>
