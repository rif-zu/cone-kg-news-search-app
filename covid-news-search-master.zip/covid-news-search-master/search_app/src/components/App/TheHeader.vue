<template>
  <v-app-bar :dense="dense" app>
    <v-toolbar-title class="mr-6 ml-4 hidden-md-and-down">
      <router-link to="/">
        Cone-KG News Search
      </router-link>
    </v-toolbar-title>

<!--    <div v-if="wasConnected" id="navbar_cluster_health" class="inline-block mt-1 hidden-xs-only">-->
<!--      <span class="mx-1 hidden-sm-and-down">{{ clusterInfo }}</span>-->
<!--      <div :title="`Cluster health: ${clusterHealth}`" class="d-inline-block mx-1">-->
<!--        <svg height="14" width="14">-->
<!--          <circle :class="`health&#45;&#45;${clusterHealth}`" cx="7" cy="9" r="5"/>-->
<!--        </svg>-->
<!--      </div>-->
<!--    </div>-->

    <div class="flex-grow-1"/>

    <v-toolbar-items v-if="wasConnected">
      <v-btn id="navbar_search" text to="/search">Search</v-btn>
<!--      <v-btn id="navbar_search_document" text to="/documents">Documents</v-btn>-->
<!--      <v-btn id="navbar_home" exact text to="/stats">Stats</v-btn>-->
    </v-toolbar-items>
  </v-app-bar>
</template>

<script>
import ConnectionStatus from '@/mixins/ConnectionStatus'
import Timer from '@/components/shared/Timer'
import Request from '@/mixins/Request'
import {CONNECTION_STATES} from '@/consts'
import {truncate, urlWithoutCredentials} from '@/helpers'

export default {
  name: 'app-header',
  components: {
    Timer
  },
  mixins: [
    ConnectionStatus,
    Request
  ],
  data() {
    return {
      drawer: false,
      clusterHealth: CONNECTION_STATES.UNKNOWN,
      scrolledDown: false
    }
  },
  computed: {
    clusterInfo() {
      return truncate(urlWithoutCredentials(this.$store.state.connection.elasticsearchHost), 45)
    },
    navbarSnapshotClasses() {
      return {
        'v-btn--active': /^\/snapshot/.test(this.$route.path)
      }
    },
    dense() {
      return this.$vuetify.breakpoint.mdAndDown || this.scrolledDown
    },
    logoSize() {
      if (this.dense) {
        return '32'
      } else {
        return '48'
      }
    }
  },
  watch: {
    wasConnected(val) {
      if (val) {
        this.getHealth()
        if (!this.getHealthInterval) {
          this.getHealthInterval = setInterval(() => {
            this.getHealth()
          }, 30000)
        }
      }
    }
  },
  created() {
    this.getHealthInterval = null

    if (this.wasConnected) {
      this.getHealth()
      if (!this.getHealthInterval) {
        this.getHealthInterval = setInterval(() => {
          this.getHealth()
        }, 30000)
      }
    }
    if (typeof window !== 'undefined') window.addEventListener('scroll', this.setScrolledDown)
  },
  destroyed() {
    if (typeof window !== 'undefined') window.removeEventListener('scroll', this.setScrolledDown)
  },
  methods: {
    setScrolledDown() {
      this.scrolledDown = window.pageYOffset > 0
    },
    getHealth() {
      this.callElasticsearch('clusterHealth')
        .then(result => (this.clusterHealth = result.status))
        .catch(() => (this.clusterHealth = CONNECTION_STATES.UNKNOWN))
    }
  }
}
</script>
