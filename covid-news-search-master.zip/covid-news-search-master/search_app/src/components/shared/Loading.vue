<template>
  <v-progress-linear color="blue" indeterminate/>
</template>

<script>
  export default {
    name: 'loading'
  }
</script>
