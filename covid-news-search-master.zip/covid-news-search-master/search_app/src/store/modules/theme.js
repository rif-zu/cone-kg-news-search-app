export const theme = {
  namespaced: true,
  state: {
    dark: false
  },
  mutations: {
    setDark (state, dark) {
      state.dark = dark
    }
  }
}
