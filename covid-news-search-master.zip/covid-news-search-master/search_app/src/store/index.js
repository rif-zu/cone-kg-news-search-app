import Vue from 'vue'
import Vuex from 'vuex'
import { plugins } from './plugins'
import { connection } from './modules/connection'
import { nodes } from './modules/nodes'
import { search } from './modules/search'
import { snackbar } from './modules/snackbar'
import { theme } from './modules/theme'

Vue.use(Vuex)

export default new Vuex.Store({
  plugins: plugins,
  modules: {
    connection,
    nodes,
    search,
    snackbar,
    theme
  }
})
