<template>
  <div>

    <div v-if="same_social.length >0">
      <v-card>
        <v-card-title>
          <span v-if="same_social_title !== ''">More from {{ same_social_title }}</span>
          <span v-if="same_social_title == ''">Same publisher</span>
        </v-card-title>
        <v-card-text>
          <ul>
            <li v-for="item in same_social">
              <router-link
                :to="documentRoute(item)"
              > [{{ item.date | formatDate }}] {{ item.title }}
              </router-link>
            </li>
          </ul>
        </v-card-text>
      </v-card>
    </div>


    <div v-if="same_author.length >0">
      <v-card>
        <v-card-title>
          <span v-if="same_author_title !== ''">More from {{ same_author_title }}</span>
          <span v-if="same_author_title == ''">Same author</span>
        </v-card-title>
        <v-card-text>
          <ul>
            <li v-for="item in same_author">
              <router-link
                :to="documentRoute(item)"
              > [{{ item.date | formatDate }}] {{ item.title }}
              </router-link>
            </li>
          </ul>
        </v-card-text>
      </v-card>
    </div>


  </div>
</template>

<script>
import {SparqlEndpointFetcher} from "fetch-sparql-endpoint";
import * as consts from "../consts";
import sameAuthorSparql from './get_author_related.sparql';
import metadataRelatedSparql from './get_social_metadata_related.sparql';

function getAuthorSparql(uri) {
  return sameAuthorSparql.replace(/DOCUMENT_URI/g, uri)
}

function getSocialSparql(uri) {
  return metadataRelatedSparql.replace(/DOCUMENT_URI/g, uri)
}

export default {
  name: 'Relations',
  props: ['uri'],
  components: {},
  data() {
    return {
      same_author: [],
      same_social: [],
      same_social_title: '',
      same_author_title: ''
    }
  },
  created: async function () {
    this.fetcher = new SparqlEndpointFetcher();

    // get_author_related.sparql
    this.authorSparql = await this.fetcher.fetchBindings(
      consts.SPARQL_ENDPOINT, getAuthorSparql(this.uri));
    this.authorSparql.on('data', (bindings) => {
      this.same_author.push({
        uri: bindings['s'].value,
        date: bindings['date'].value,
        title: bindings['title_description'].value
      })
      this.same_author_title = bindings['author_description'].value
    })

    // get_social_metadata_related.sparql
    this.socialSparql = await this.fetcher.fetchBindings(
      consts.SPARQL_ENDPOINT, getSocialSparql(this.uri));
    this.socialSparql.on('data', (bindings) => {
      this.same_social.push({
        uri: bindings['s'].value,
        date: bindings['date'].value,
        title: bindings['title_description'].value
      })
      this.same_social_title = bindings['part_description'].value
    })

  },
  methods: {
    documentRoute(item) {
      return {name: 'DocumentByURI', params: {uri: item.uri}}
    }
  }
}
</script>

