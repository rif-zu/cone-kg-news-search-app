<template>
  <div>
    <template>
      <v-container fluid>
          <v-data-iterator
          :class="tableClasses"
          :footer-props="{itemsPerPageOptions: [10, 20, 100, 1000, 10000]}"
          :headers="filteredHeaders"
          :items="items"
          :server-items-length="totalHits"
          :loading="loading || filterLoading"
          :options.sync="options"
        >
          <template v-slot:header>
            <v-card-text>
              <div class="clearfix">
                <span class="grey--text">Showing results for: <span class="font--mono">"{{ q }}"</span></span>
              </div>
            </v-card-text>
          </template>

          <template v-slot:default="props">
            <v-row>
              <v-col
                v-for="item in props.items"
                :key="item.name"
                cols="12"
                sm="6"
                md="4"
                lg="3"
              >
                <v-card>
                  <v-card-title class="fix">
                    <router-link
                      :to="documentRoute(item)"
                    >{{ item.title }}
                    </router-link>
                  </v-card-title>

                  <v-card-subtitle class="fix">{{ item.published_date| formatDate }}</v-card-subtitle>
                  <v-card-text class="fix">{{ item.content | truncate(300, '...') }}</v-card-text>

                  <div v-if="item.image_urls != null" v-for="(image, index) in item.image_urls">
<!--                    I'm showing only the first photo-->
                    <template v-if="index == 0">
                      <v-img
                        :src="image"
                        max-height="200"
                      ></v-img>
                    </template>
                  </div>

                </v-card>
              </v-col>

            </v-row>
          </template>

          <template slot="no-data">
            <template v-if="q !== '*' && filter !== ''">
              No entries found that match your search <i>{{ q }}</i> and your filter <i>{{ filter }}</i>.
            </template>
            <template v-else-if="q !== '*'"> No entries found that match your search <i>{{ q }}</i>.</template>
            <template v-else-if="filter !== ''"> No entries found that match your filter <i>{{ filter }}</i>.</template>
            <template v-else>Nothing found.</template>
          </template>

          <v-progress-linear slot="progress" color="blue" indeterminate/>

        </v-data-iterator>
      </v-container>
    </template>

  </div>
</template>

<script>
import {fixedTableHeaderOnDisable, fixedTableHeaderOnEnable, resetTableHeight} from '@/mixins/FixedTableHeader'
import {mapVuexAccessors} from '@/helpers/store'
import Results from '@/models/Results'
import AsyncFilter from '@/mixins/AsyncFilter'
import {mapState} from 'vuex'
import esAdapter from '@/mixins/GetAdapter'

export default {
  name: 'NewsResultsTable',
  components: {},
  mixins: [AsyncFilter],
  props: {
    body: {
      default: () => ({}),
      type: Object
    },
    loading: {
      default: false,
      type: Boolean
    }
  },
  data() {
    return {
      items: [],
      modalOpen: false,
      modalMethodParams: {},
      headers: []
    }
  },
  computed: {
    hits() {
      if (!this.body) return []
      if (!this.body.hits) return []

      return this.body.hits.hits
    },
    totalHits() {
      if (!this.body) return 0
      if (!this.body.hits) return 0
      if (typeof this.body.hits.total === 'object') return this.body.hits.total.value

      return this.body.hits.total
    },
    filteredColumns() {
      if (this.columns.length === this.selectedColumns.length) {
        return this.columns
      } else {
        return this.columns.filter(k => this.selectedColumns.includes(k))
      }
    },
    filteredHeaders() {
      let headers = []
      if (this.headers.length === this.selectedColumns.length) {
        headers = this.headers
      } else {
        headers = this.headers.filter(h => this.selectedColumns.includes(h.originalValue))
      }

      return headers.concat({
        text: '',
        value: 'actions',
        sortable: false
      })
    },
    stickyTableHeader: {
      get() {
        return this.$store.state.search.stickyTableHeader
      },
      set(value) {
        if (!value) resetTableHeight()
        this.$store.commit('search/setStickyTableHeader', value)
      }
    },
    tableClasses() {
      return [
        'table--condensed',
        {'table--fixed-header': this.stickyTableHeader}
      ]
    },
    openDocumentClasses() {
      return [
        'v-btn',
        'v-size--default',
        {'theme--dark': this.$store.state.theme.dark},
        {'theme--light': !this.$store.state.theme.dark}
      ]
    },
    ...mapVuexAccessors('search', ['filter', 'options', 'selectedColumns', 'columns']),
    ...mapState('search', ['q'])
  },
  watch: {
    hits(val) {
      if (val.length === 0 && this.hits.length === 0) {
        this.items = []
        return
      }

      const oldColumns = this.columns
      const results = new Results(this.hits)
      this.columns = results.uniqueColumns
      const newColumns = this.columns.filter(m => !oldColumns.includes(m))
      this.selectedColumns = this.selectedColumns.concat(newColumns)
      const resultIndices = results.uniqueIndices

      esAdapter()
        .then(adapter => adapter.indexGet({index: resultIndices}))
        .then(indices => {
          const allProperties = {}

          this.callFuzzyTableFilter(val, this.filter, true)
        })
    },
    filter(val) {
      this.callFuzzyTableFilter(this.hits, val, val.length === 0)
    }
  },
  mounted() {
    fixedTableHeaderOnEnable()
  },
  beforeDestroy() {
    fixedTableHeaderOnDisable()
  },
  methods: {
    async callFuzzyTableFilter(items, filter, skipTimeout) {
      this.debounceFilter(async () => {
        let filteredResults = await this.filterTable(items, filter, this.filteredColumns, skipTimeout)
        this.items = filteredResults.map(el => Object.assign(el, el._source) && delete el._source && el)
      }, skipTimeout)
    },
    documentRoute(item) {
      return {name: 'Document', params: {index: item._index, type: item._type, id: item._id}}
    }
  }
}
</script>
