import text_to_clean from './text_to_clean.txt';

const phrases = text_to_clean.split('\n')

function escapeRegExp(string){
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function replaceAll(str, term, replacement) {
  return str.replace(new RegExp(escapeRegExp(term), 'g'), replacement);
}

export function text_cleaning(text) {
  // Take out all phrases from the file
  for (let phrase of phrases){
    text = replaceAll(text,phrase,'')
  }
  // Remove several consecutive \n
  text = text.replace(/\n\s*\n/g, '\n');

  // Add an additional break where a paragraph is detected
  text = replaceAll(text,'.\n','.\n\n')

  return text
}
