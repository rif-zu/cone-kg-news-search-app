const label_descriptions = {
  "person": "People, including fictional.",
  "norp": "Nationalities or religious or political groups.",
  "facility": "Buildings, airports, highways, bridges, etc.",
  "fac": "Buildings, airports, highways, bridges, etc.",
  "org": "Companies, agencies, institutions, etc.",
  "gpe": "Countries, cities, states.",
  "loc": "Non-GPE locations, mountain ranges, bodies of water.",
  "product": "Objects, vehicles, foods, etc. (Not services.)",
  "event": "Named hurricanes, battles, wars, sports events, etc.",
  "work_of_art": "Titles of books, songs, etc.",
  "language": "Any named language.",
  "date": "Absolute or relative dates or periods.",
  "time": "Times smaller than a day.",
  "percent": "Percentage, including '%“.",
  "money": "Monetary values, including unit.",
  "quantity": "Measurements, as of weight or distance.",
  "ordinal": "'first', 'second', etc.",
  "cardinal": "Numerals that do not fall under another type."
}

function deactivated_by_default(label) {
  let excluded = ['cardinal','ordinal','date']
  return excluded.indexOf(label) > -1;
}

export function getEnabledEntities(ner_response) {
  let label_counts = {}
  for (let entity of ner_response) {
    let label = entity.label.toLowerCase()
    if (label in label_counts) {
      label_counts[label] += 1
    } else {
      label_counts[label] = 1
    }
  }
  let enabled_entities = []
  for (let label in label_counts) {
    enabled_entities.push(
      {
        label: label,
        counts: label_counts[label],
        description: label_descriptions[label],
        enabled: !deactivated_by_default(label)
      }
    )
  }
  return enabled_entities
}

export function filter_enabled(ner_response, enabled_entities) {
  for (let entity of enabled_entities) {
    if (!entity.enabled) {
      ner_response = ner_response.filter(function (current) {
        return current.label.toLowerCase() !== entity.label;
      });
    }
  }
  return ner_response
}
