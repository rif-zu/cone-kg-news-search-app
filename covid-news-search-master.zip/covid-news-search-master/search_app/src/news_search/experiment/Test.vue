<template>
  <div>
    <word tooltip_position="bottom" tooltip_content="Bottom tooltip" text="Some text"/>

    <div v-if="resources && resources.length">
      <Highlighter class="my-highlight"
                   :style="{ }"
                   highlightClassName="highlight"
                   :resources="resources"
                   :autoEscape="true"
                   :textToHighlight="text"/>
    </div>

    <ul v-if="resources && resources.length">
      <li v-for="resource of resources">
        <p><strong>{{ resource }}</strong></p>
      </li>
    </ul>

    <ul v-if="errors && errors.length">
      <li v-for="error of errors">
        {{ error.message }}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';
import Highlighter from './VueHighlightWords'
import Word from './Word'

export default {
  components: {
    Highlighter,
    Word
  },
  data() {
    return {
      posts: [],
      errors: [],
      resources: [],
      text: 'President Obama called Wednesday on Congress to extend a tax break\n' +
        'for students included in last year\'s economic stimulus package, arguing\n' +
        'that the policy provides more generous assistance.',
    }
  },
  computed: {
    // keywords() {
    //   return this.words.split(' ')
    // }
  },
  created() {
    //   curl --header "Content-Type: application/json" \
    // --request POST \
    // --data '{"text":"Net income was $9.4 million compared to the prior year of $2.7 million. Google is a big company.","model":"en_core_web_sm"}' \
    // http://18.134.14.161:8080/ent

    // pip install hug==2.4.1

    axios.post('http://18.134.14.161:8080/ent'
      , {
        text:this.text,
        model:'en_core_web_sm'
      }, {
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(response => {
      this.resources = response.data
    })
      .catch(e => {
        console.log(e)
        this.errors.push(e)
      })

    // DBPedia
    // axios.get('http://18.134.14.161:8080/nlp/parse', {
    //   params: {
    //     sentence: this.text,
    //   },
    //   headers: {
    //     'Accept': 'application/json'
    //   }
    // }).then(response => {
    //   console.log(response.data)
    //   this.resources = response.data['Resources']
    // })
    //   .catch(e => {
    //     console.log(e)
    //     this.errors.push(e)
    //   })

  }
}
</script>
<style>
/*.highlight {*/
/*  !*background-color: #e3a872;*!*/
/*  !*color: white;*!*/
/*  border: 1px solid black;*/
/*  margin: 1px;*/
/*  padding: 1px;*/
/*}*/

</style>
