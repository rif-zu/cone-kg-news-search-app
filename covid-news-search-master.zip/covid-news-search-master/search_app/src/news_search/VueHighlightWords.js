export default {
  functional: true,
  props: {
    textToHighlight: {
      type: String,
      required: true
    },
    resources: {
      type: Array,
      required: true
    },
  },
  render(h, context) {
    const {
      textToHighlight,
    } = context.props

    const contextData = context.data

    let chunks = []
    let last = 0
    for (let resource of context.props.resources) {
      let start = resource['start']
      let end = resource['end']
      if ((start - last > 1)) {
        chunks.push({
          start: last,
          end: start,
          highlight: false,
        })
      }
      chunks.push({
        start: start,
        end: end,
        highlight: true,
        label: resource['label']
      })
      last = end
    }
    chunks.push({
      start: last,
      end: textToHighlight.length,
      highlight: false,
    })

    return h(
      'div',
      {...contextData},

      chunks.map((chunk, index) => {
        const text = textToHighlight.substr(
          chunk.start,
          chunk.end - chunk.start
        )
        // Print a word wrapped by the mark and the corresponding class
        if (chunk.highlight) {
          return h(
            'mark',
            {
              attrs: {'data-entity': chunk.label.toLowerCase()}
            },
            text
          )

        } else {
          // Return plain text word
          return context._v(text);
        }
      })
    )
  }
}
