<template>

  <div v-if="data.hits != null">
    <v-container fluid>
      <v-row>
        <v-col
          v-for="item in data.hits.hits"
          :key="item.name"
          cols="4"
          sm="12"
          md="4"
          lg="4"
        >
          <v-card>
            <v-card-title class="fix">
              <router-link
                :to="documentRoute(item)"
              >{{ item._source.title }}
              </router-link>
            </v-card-title>
            <v-card-subtitle class="fix">{{ item._source.published_date| formatDate }}</v-card-subtitle>
            <v-card-text class="fix">{{ item._source.content | truncate(1200, '...') }}</v-card-text>

            <div v-if="item._source.image_urls != null" v-for="(image, index) in item._source.image_urls">
              <template v-if="index == 0">
                <v-img
                  :src="image"
                  max-height="200"
                ></v-img>
              </template>
            </div>

          </v-card>
        </v-col>

      </v-row>
    </v-container>

  </div>
</template>
<script>

export default {
  name: 'NewsResultsTable',
  components: {},
  props: {
    data: {
      default: () => ({}),
      type: Object
    },
  },
  methods: {
    documentRoute(item) {
      return {name: 'Document', params: {index: item._index, type: item._type, id: item._id}}
    }
  }
}
</script>
