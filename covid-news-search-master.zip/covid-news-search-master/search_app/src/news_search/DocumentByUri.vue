<template>
  <div>{{ route }}</div>
</template>

<script>
import esAdapter from '../mixins/GetAdapter'
import {DEFAULT_SEARCH_PARAMS} from "../consts";

export default {
  name: 'DocumentByUri',
  components: {
    Document,
  },
  data() {
    return {
      parameters: null,
      route: null
    }
  },
  created: async function () {
    let uri = this.params.uri
    if (uri != null) {

      let id = uri.replace('http://www.tentex.io/data/news/', '')
      let parameters = {
        "query": {
          "match": {
            "_id": id,
          }
        },
        "size": 1,
        "index": DEFAULT_SEARCH_PARAMS.index
      }
      esAdapter()
        .then(adapter => adapter.search_plain(parameters))
        .then(response => {
          let hit = response['hits']['hits'][0]

          if (hit!=null){
            this.$router.push({
              name: 'Document',
              params: {index: hit._index, type: hit._type, id: hit._id}
            })
          } else {
            console.log('Warning: '+this.params.uri+' not found in elastic search')
          }
        })
    }
  },
  computed: {
    params() {
      return this.$route.params
    },
  }
}
</script>
