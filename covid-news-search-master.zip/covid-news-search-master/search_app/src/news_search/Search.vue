<template>
  <v-card>
    <v-card-text>
      <v-form @submit.prevent="loadData">
        <v-row>
          <v-col cols="12" md="9" sm="12">
            <v-text-field id="query"
                          v-model="query"
                          append-icon="mdi-close"
                          autofocus
                          label="Search"
                          placeholder="Enter terms"
                          name="query"
                          @keyup.esc="resetQuery"
                          @click:append="resetQuery">
              <template v-slot:message="{ message }">
                <span v-html="message"/>
              </template>
            </v-text-field>
          </v-col>

          <v-col cols="12" sm="1">
            <v-btn id="search_submit" class="mt-4" color="primary" type="submit">Search</v-btn>
          </v-col>
        </v-row>

      </v-form>
    </v-card-text>
    <v-divider/>

    <div v-if="showPopular">
      <popular :data="popular"/>

    </div>
    <div v-else>
      <news-results-table :body="body" :loading="false"/>
    </div>

  </v-card>
</template>

<script>
import Request from '@/mixins/Request'
import NewsResultsTable from '@/news_search/NewsResultsTable.vue'
import Popular from '@/news_search/Popular.vue'

import {mapVuexAccessors} from '@/helpers/store'
import {search_dsl, search_popular} from "../consts";

export default {
  name: 'Search',
  mixins: [Request],

  components: {
    NewsResultsTable,
    Popular
  },
  props: {
    executeSearch: {
      default: false,
      type: Boolean
    },
  },
  data() {
    return {
      showPopular: true,
      popular: {},
      query: this.q?this.q:'',
    }
  },
  computed: {
    searchParams() {
      let order = null
      if (Array.isArray(this.options.sortDesc) && this.options.sortDesc.length > 0) {
        order = this.options.sortDesc[0] ? 'desc' : 'asc'
      }
      return {
        q: search_dsl(this.query),
        index: '*',
        source: this.source,
        size: this.options.itemsPerPage,
        from: (this.options.page - 1) * this.options.itemsPerPage,
        sort: this.sortBy,
        order
      }
    },
    sortBy() {
      if (Array.isArray(this.options.sortBy) && this.options.sortBy.length > 0) {
        return this.options.sortBy[0]
      } else {
        return null
      }
    },
    ...mapVuexAccessors('search', ['q', 'indices', 'source', 'options', 'filter'])
  },
  created () {
    if (this.executeSearch && this.query !=null && this.query !== "") {
      this.query = this.q
      this.loadData()
    } else {
      this.loadPopular()
    }
  },
  methods: {
    async loadPopular() {
      let search_for_popular_params = {
        q: search_popular(),
        index: '*',
        source: this.source,
        size: 10,
      }
      await this.callElasticsearch('search', search_for_popular_params)
        .then(response => (this.popular = response))
    },
    async loadData() {
      this.showPopular = false
      await this.callElasticsearch('search', this.searchParams)
        .then(response => (this.body = response))
      this.q = this.query
    },
    resetQuery() {
      this.showPopular = true
      this.query = ''
    },
  }
}
</script>
