<template>
  <div>
    <data-loader ref="dataLoader" :method-params="methodParams" method="get">
      <template v-slot:default="data">
        <v-row>
          <v-col cols="8" sm="8" md="8" lg="8">
            <tagged-text :data="data.body._source"></tagged-text>
          </v-col>
          <v-col cols="4">
            <v-card v-if="data.body._source != null">
              <v-card-title>
                <relations :uri="data.body._source.uri"></relations>
              </v-card-title>
              <v-card-text>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </template>
    </data-loader>
  </div>
</template>

<script>
import BackButton from '@/components/shared/BackButton'
import DataLoader from '@/components/shared/DataLoader'
import Relations from "./Relations";
import TaggedText from "./TaggedText";

export default {
  name: 'Document',
  components: {
    BackButton,
    DataLoader,
    Relations,
    TaggedText
  },
  computed: {
    params() {
      return this.$route.params
    },
    methodParams() {
      return {index: this.params.index, type: this.params.type, id: this.params.id}
    },
    caption() {
      const docType = this.params.type || '_doc'
      return `${this.params.index}/${docType}/${this.params.id}`
    },
    test() {
      return this.methodParams
    }
  }
}
</script>
