<template>
  <div v-if="data != null">
    <v-card>
      <v-card-title>
        <a :href="data.source_url">{{ data.title }}</a>
        <back-button :route="{name: 'Search', params: {executeSearch: true}}"/>
      </v-card-title>
      <v-card-subtitle>
        Date {{ data.published_date| formatDate }}
        <div v-if="data.source !== ''">{{ data.source }}</div>
        <div v-if="data.author !== ''">{{ data.author }}</div>
      </v-card-subtitle>
      <v-card-text>
      <span style="white-space: pre-wrap;">
      <Highlighter v-if="filtered_resources && filtered_resources.length"
                   class="entities"
                   :resources="filtered_resources"
                   :textToHighlight="cleaned_content"/>
        <span v-else>{{ cleaned_content }}</span>
      </span>
        <v-row>
          <v-col
            v-for="image in data.image_urls"
            :key="image"
            cols="6" sm="6" md="4" lg="3">
            <v-img
              :src="image"
            ></v-img>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <!--    Section of entity section-->
    <div v-if="enabled_entities !=null">
      <v-divider/>
      <v-card>
        <v-card-title>
          Entities
        </v-card-title>
        <v-card-text>
          <ul>
            <li v-for="(current_entity, index) in enabled_entities">
              <input type="checkbox" :id="index" v-model="current_entity.enabled">
              <mark :data-entity="current_entity.label">{{ current_entity.description }}</mark>
              {{ current_entity.counts }}
            </li>
          </ul>
        </v-card-text>
      </v-card>
    </div>

    <!--    Section for keywords-->
    <div v-if="data.keywords != null">
      <v-divider/>
      <v-card>
        <v-card-title>
          Keywords
        </v-card-title>
        <v-card-text>
          <v-chip v-for="(keyword, index) in data.keywords" class="ma-2">{{ keyword }}</v-chip>
        </v-card-text>
      </v-card>
    </div>

  </div>
</template>

<script>

import BackButton from "../components/shared/BackButton";
import axios from 'axios';
import Highlighter from "./VueHighlightWords";
import {NER_SERVICE_HOST} from "../consts";
import {text_cleaning} from "./text_cleaning";
import {getEnabledEntities} from "./entity_processing";
import {filter_enabled} from "./entity_processing";

export default {
  name: 'TaggedText',
  props: ['data'],
  components: {
    BackButton,
    Highlighter,
  },
  data() {
    return {
      resources: [],
      enabled_entities: [],
      cleaned_content: ''
    }
  },

  watch: {
    data: function (val) {
      this.cleaned_content = text_cleaning(this.data.content)
      if (this.data != null) {
        axios.post(NER_SERVICE_HOST
          , {
            text: this.cleaned_content,
            model: 'en_core_web_sm'
          }, {
            headers: {
              'Content-Type': 'application/json'
            }
          }).then(response => {

          this.resources = response.data
          this.enabled_entities = getEnabledEntities(this.resources)
        })
          .catch(e => {
            console.log(e)
            this.errors.push(e)
          })
      }
    }
  },
  computed: {
    filtered_resources() {
      return filter_enabled(this.resources, this.enabled_entities)
    }
  },
  methods: {}
}
</script>

<style>

.entities {
  line-height: 2;
}

[data-entity] {
  padding: 0.25em 0.35em;
  margin: 0px 0.25em;
  line-height: 1;
  display: inline-block;
  border-radius: 0.25em;
  border: 1px solid;
}

[data-entity]::after {
  box-sizing: border-box;
  content: attr(data-entity);
  font-size: 0.6em;
  line-height: 1;
  padding: 0.35em;
  border-radius: 0.35em;
  text-transform: uppercase;
  display: inline-block;
  vertical-align: middle;
  margin: 0px 0px 0.1rem 0.5rem;
}

[data-entity][data-entity="person"] {
  background: rgba(166, 226, 45, 0.2);
  border-color: rgb(166, 226, 45);
}

[data-entity][data-entity="person"]::after {
  background: rgb(166, 226, 45);
}

[data-entity][data-entity="norp"] {
  background: rgba(224, 0, 132, 0.2);
  border-color: rgb(224, 0, 132);
}

[data-entity][data-entity="norp"]::after {
  background: rgb(224, 0, 132);
}

[data-entity][data-entity="facility"] {
  background: rgba(67, 198, 252, 0.2);
  border-color: rgb(67, 198, 252);
}

[data-entity][data-entity="facility"]::after {
  background: rgb(67, 198, 252);
}

[data-entity][data-entity="fac"] {
  background: rgba(67, 198, 252, 0.2);
  border-color: rgb(67, 198, 252);
}

[data-entity][data-entity="fac"]::after {
  background: rgb(67, 198, 252);
}

[data-entity][data-entity="org"] {
  background: rgba(67, 198, 252, 0.2);
  border-color: rgb(67, 198, 252);
}

[data-entity][data-entity="org"]::after {
  background: rgb(67, 198, 252);
}

[data-entity][data-entity="gpe"] {
  background: rgba(253, 151, 32, 0.2);
  border-color: rgb(253, 151, 32);
}

[data-entity][data-entity="gpe"]::after {
  background: rgb(253, 151, 32);
}

[data-entity][data-entity="loc"] {
  background: rgba(253, 151, 32, 0.2);
  border-color: rgb(253, 151, 32);
}

[data-entity][data-entity="loc"]::after {
  background: rgb(253, 151, 32);
}

[data-entity][data-entity="product"] {
  background: rgba(142, 125, 255, 0.2);
  border-color: rgb(142, 125, 255);
}

[data-entity][data-entity="product"]::after {
  background: rgb(142, 125, 255);
}

[data-entity][data-entity="event"] {
  background: rgba(255, 204, 0, 0.2);
  border-color: rgb(255, 204, 0);
}

[data-entity][data-entity="event"]::after {
  background: rgb(255, 204, 0);
}

[data-entity][data-entity="work_of_art"] {
  background: rgba(255, 204, 0, 0.2);
  border-color: rgb(255, 204, 0);
}

[data-entity][data-entity="work_of_art"]::after {
  background: rgb(255, 204, 0);
}

[data-entity][data-entity="language"] {
  background: rgba(255, 204, 0, 0.2);
  border-color: rgb(255, 204, 0);
}

[data-entity][data-entity="language"]::after {
  background: rgb(255, 204, 0);
}

[data-entity][data-entity="date"] {
  background: rgba(47, 187, 171, 0.2);
  border-color: rgb(47, 187, 171);
}

[data-entity][data-entity="date"]::after {
  background: rgb(47, 187, 171);
}

[data-entity][data-entity="time"] {
  background: rgba(47, 187, 171, 0.2);
  border-color: rgb(47, 187, 171);
}

[data-entity][data-entity="time"]::after {
  background: rgb(47, 187, 171);
}

[data-entity][data-entity="percent"] {
  background: rgba(153, 153, 153, 0.2);
  border-color: rgb(153, 153, 153);
}

[data-entity][data-entity="percent"]::after {
  background: rgb(153, 153, 153);
}

[data-entity][data-entity="money"] {
  background: rgba(153, 153, 153, 0.2);
  border-color: rgb(153, 153, 153);
}

[data-entity][data-entity="money"]::after {
  background: rgb(153, 153, 153);
}

[data-entity][data-entity="quantity"] {
  background: rgba(153, 153, 153, 0.2);
  border-color: rgb(153, 153, 153);
}

[data-entity][data-entity="quantity"]::after {
  background: rgb(153, 153, 153);
}

[data-entity][data-entity="ordinal"] {
  background: rgba(153, 153, 153, 0.2);
  border-color: rgb(153, 153, 153);
}

[data-entity][data-entity="ordinal"]::after {
  background: rgb(153, 153, 153);
}

[data-entity][data-entity="cardinal"] {
  background: rgba(153, 153, 153, 0.2);
  border-color: rgb(153, 153, 153);
}

[data-entity][data-entity="cardinal"]::after {
  background: rgb(153, 153, 153);
}
</style>

