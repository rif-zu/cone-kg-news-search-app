<template>
  <v-row>
    <v-col lg="10" offset-lg="1" offset-xl="2" xl="8">
      <v-card>
        <v-card-text>
          <h2 v-if="enableCorsHint" class="text-h6 mb-1">Test and connect</h2>
          <test-and-connect/>
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
import TestAndConnect from '@/components/Setup/TestAndConnect'

export default {
  name: 'setup',
  components: {
    TestAndConnect
  },
  data() {
    return {
      enableCorsHint: process.env.VUE_APP_DISABLE_CORS_HINT !== 'true'
    }
  }
}
</script>
