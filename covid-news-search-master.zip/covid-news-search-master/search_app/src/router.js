import Vue from 'vue'
import Router from 'vue-router'
import Setup from '@/views/Setup'
import Search from '@/news_search/Search'
import Document from '@/news_search/Document'
import DocumentByUri from '@/news_search/DocumentByUri'
import Store from '@/store'

Vue.use(Router)

const router = new Router({
  mode: process.env.VUE_APP_ROUTER_MODE || 'history',
  routes: [
    {
      path: '/setup',
      name: 'Setup',
      component: Setup,
      beforeEnter: (to, from, next) => {
        if (Store.state.connection.wasConnected) {
          next('/')
        } else {
          next()
        }
      }
    },
    {
      path: '/search',
      name: 'Search',
      component: Search,
      props: true
    },
    {
      path: '/search/:index/:type?/:id',
      name: 'Document',
      component: Document
    },
    {
      path: '/search_by_uri/:uri',
      name: 'DocumentByURI',
      component: DocumentByUri
    },
    {
      path: '*',
      beforeEnter: (to, from, next) => {
        next('/search') // redirect "404" to root url
      }
    }
  ]
})

router.beforeEach((to, from, next) => {
  if (!Store.state.connection.wasConnected && to.name !== 'Setup') {
    next('setup')
  } else {
    next()
  }
})

export default router
