curl -u elastic:changeme -X PUT "18.133.76.183:9200/_snapshot/my_backup?pretty" -H 'Content-Type: application/json' -d'
{
  "type": "fs",
  "settings": {
    "location": "/home/ubuntu/backups/elastic"
  }
}'

