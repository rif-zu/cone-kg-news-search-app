
There are 4 components to backup.

1. Virtuoso database (the triplestore)
2. Elastic search
3. Named entity recognition service 
4. The search application

To download the files you can use FTP to login to the servers at:

18.134.14.161
18.133.76.183

the username is ubuntu

# Component 1: Virtuoso

## Backup

From the server: 18.134.14.161

Download all the files from:

/home/ubuntu/virtuoso (virtuoso database)

## Restore

1. Install docker
2. Put the database in /home/ubuntu/virtuoso/database
3. Start a new virtuoso instance with:

sudo docker run --name my-virtuoso \
   -p 8890:8890 -p 1111:1111 \
   -e DBA_PASSWORD=dba \
   -e SPARQL_UPDATE=true \
   -e DEFAULT_GRAPH=http://www.tentex.io/data/news \
   -v /home/ubuntu/virtuoso/database:/data \
   -d tenforce/virtuoso
  
where /home/ubuntu/virtuoso/database is where the database is.

It will take some time to start 

Check the sparql endpoint at:

localhost:8890/sparql 

# Component 2: Elastic search

## Backup

1. Download all the files from:

/home/ubuntu/backups/elastic (a snapshot of the elastic-search database)

## Restore

Install an elastic search database (I used version 7.9)

https://www.elastic.co/guide/en/elasticsearch/reference/current/install-elasticsearch.html#install-elasticsearch

Add the following lines to the elasticsearch.yml file:

http.cors.enabled : true
http.cors.allow-origin : "*"
http.cors.allow-methods : OPTIONS, HEAD, GET, POST, PUT, DELETE
http.cors.allow-headers : X-Requested-With,X-Auth-Token,Content-Type, Content-Length, Authorization
transport.host: localhost
transport.tcp.port: 9300
http.port: 9200
network.host: 0.0.0.0
xpack.security.enabled: true
xpack.security.authc.api_key.enabled: true
path.repo: ["/home/ubuntu/backups/elastic"]

note that path.repo points to the snapshot

1. Start elastic search
2. Restore the snapshot using the API

https://www.elastic.co/guide/en/elasticsearch/reference/current/snapshots-restore-snapshot.html

curl -X POST "localhost:9200/_snapshot/my_backup/snapshot_1/_restore?pretty"

# Component 3: NER

## Backup

From the server: 18.134.14.161

Download all the files from:

/home/ubuntu/ner (spacy's named entity recognition)

## Install and run the service

1. install python
2. install the python dependencies and language models.

> pip install spacy
> pip install hug
> pip install hug-middleware-cors
> pip install waitress
> pip install spacy
> spacy download en_core_web_sm
> spacy link en_core_web_sm en

run the application at:

/home/ubuntu/ner/spacy-services/displacy/app.py

# Component 4: The search application

There is no need to backup the search application, but you can clone:

https://github.com/cristianvasquez/covid-news-search

Or download: 

https://github.com/cristianvasquez/covid-news-search/archive/master.zip

## Restore

Change the file:

/covid-news-search/search_app/src/consts.js

To specify the correct addresses

/**
 * Elastic search config
 */
export const DEFAULT_HOST = 'http://elastic:changeme@18.133.76.183:9200'

/**
 * SPARQL config
 */
export const SPARQL_ENDPOINT = 'http://18.134.14.161:8890/sparql'

/**
 * NER Service config
 */
export const NER_SERVICE_HOST = 'http://18.134.14.161:8080/ent'

## To run the app

In /covid-news-search/search_app/

Install the dependencies
```
npm install
```

Run the application:
```
npm run serve
```
