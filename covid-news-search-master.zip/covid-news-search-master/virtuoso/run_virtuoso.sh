sudo docker run --name my-virtuoso \
    -p 8890:8890 -p 1111:1111 \
    -e DBA_PASSWORD=dba \
    -e SPARQL_UPDATE=true \
    -e DEFAULT_GRAPH=http://www.tentex.io/data/news \
    -v /home/ubuntu/virtuoso/database:/data \
    -v /home/ubuntu/graphdb-import:/data/triples \
    -d tenforce/virtuoso