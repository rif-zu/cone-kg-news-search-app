docker image used to install virtuoso in the ec2-instance.

To load data Manually: 

Make the quad .nq files available in /my/path/to/the/virtuoso/db/dumps. The quad files might be compressed. Enter the Virtuoso docker, open ISQL, register and run the load.

```
sudo docker exec -it my-virtuoso bash
isql-v -U dba -P dba
SQL> ld_dir('triples', '*.n3', 'http://www.tentex.io/data/news');
SQL> rdf_loader_run();
```
Validate the ll_state of the load. If ll_state is 2, the load completed.

```
select * from DB.DBA.load_list;
```
